<?php
session_start();

// Check if the admin is logged in
if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}

// Database connection
$conn = new mysqli('localhost', 'root', '', 'textilemanagementsystem');
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Handle sorting
$sort_column = isset($_GET['sort']) ? $_GET['sort'] : 'date';
$sort_order = isset($_GET['order']) && $_GET['order'] === 'desc' ? 'desc' : 'asc';
$next_order = $sort_order === 'asc' ? 'desc' : 'asc';

// Search functionality
$search_query = isset($_GET['search']) ? trim($_GET['search']) : '';
$search_sql = $search_query ? "WHERE e.name LIKE ? OR e.email LIKE ?" : "";

// Fetch attendance records
$attendance_query = "
    SELECT a.attendance_id, e.employee_id, e.name AS employee_name, e.email, a.date, a.status
    FROM attendance a
    INNER JOIN employees e ON a.employee_id = e.employee_id
    $search_sql
    ORDER BY $sort_column $sort_order
";

$stmt = $conn->prepare($attendance_query);
if ($search_query) {
    $search_param = "%$search_query%";
    $stmt->bind_param('ss', $search_param, $search_param);
}
$stmt->execute();
$attendance_result = $stmt->get_result();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Employee Attendance List</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f6f9;
            margin: 0;
            padding: 0;
        }
        .container {
            max-width: 1000px;
            margin: 50px auto;
            background: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        }
        h1 {
            text-align: center;
            color: #333;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        table, th, td {
            border: 1px solid #ddd;
        }
        th, td {
            padding: 10px;
            text-align: center;
        }
        th {
            background-color: #007bff;
            color: white;
        }
        th a {
            color: white;
            text-decoration: none;
        }
        th a:hover {
            text-decoration: underline;
        }
        .search-container {
            margin-bottom: 20px;
            text-align: center;
        }
        .search-container input {
            padding: 8px;
            font-size: 14px;
            border: 1px solid #ddd;
            border-radius: 4px;
            width: 300px;
        }
        .search-container button {
            padding: 8px 12px;
            font-size: 14px;
            border: none;
            border-radius: 4px;
            background-color: #007bff;
            color: white;
            cursor: pointer;
        }
        .search-container button:hover {
            background-color: #0056b3;
        }
        .no-records {
            text-align: center;
            font-size: 16px;
            color: #555;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Employee Attendance List</h1>
        <a href="employee_list.php" class="btn back" style="background-color: #007bff; color: white; text-decoration: none; padding: 10px 15px; border-radius: 4px; display: inline-block; margin-bottom: 15px;">Back</a>

        <!-- Search Bar -->
        <div class="search-container">
            <form method="GET">
                <input type="text" name="search" placeholder="Search by name or email" value="<?php echo htmlspecialchars($search_query); ?>">
                <button type="submit">Search</button>
            </form>
        </div>

        <!-- Attendance Table -->
        <?php if ($attendance_result->num_rows > 0): ?>
            <table>
                <tr>
                    <th><a href="?sort=attendance_id&order=<?php echo $next_order; ?>">Attendance ID</a></th>
                    <th><a href="?sort=employee_name&order=<?php echo $next_order; ?>">Employee Name</a></th>
                    <th><a href="?sort=email&order=<?php echo $next_order; ?>">Email</a></th>
                    <th><a href="?sort=date&order=<?php echo $next_order; ?>">Date</a></th>
                    <th><a href="?sort=status&order=<?php echo $next_order; ?>">Status</a></th>
                </tr>
                <?php while ($row = $attendance_result->fetch_assoc()): ?>
                    <tr>
                        <td><?php echo $row['attendance_id']; ?></td>
                        <td><?php echo htmlspecialchars($row['employee_name']); ?></td>
                        <td><?php echo htmlspecialchars($row['email']); ?></td>
                        <td><?php echo $row['date']; ?></td>
                        <td><?php echo htmlspecialchars($row['status']); ?></td>
                    </tr>
                <?php endwhile; ?>
            </table>
        <?php else: ?>
            <p class="no-records">No attendance records found.</p>
        <?php endif; ?>
    </div>
</body>
</html>

<?php
$stmt->close();
$conn->close();
?>
