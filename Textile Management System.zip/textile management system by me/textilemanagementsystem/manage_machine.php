<?php
session_start();

// Check if admin is logged in
if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}

// Database connection
$conn = new mysqli('localhost', 'root', '', 'textilemanagementsystem');
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Add Machine
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['add_machine'])) {
    $machine_name = $_POST['machine_name'];
    $machine_type = $_POST['machine_type'];
    $status = $_POST['status'];

    $add_machine = $conn->prepare("INSERT INTO machines (machine_name, machine_type, status) VALUES (?, ?, ?)");
    $add_machine->bind_param('sss', $machine_name, $machine_type, $status);
    $add_machine->execute();
    $add_machine->close();
    echo "<script>alert('Machine added successfully.'); window.location.href='manage_machine.php';</script>";
}

// Assign Employee
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['assign_employee'])) {
    $machine_id = $_POST['machine_id'];
    $employee_id = $_POST['employee_id'];

    $assign_employee = $conn->prepare("INSERT INTO machine_assignments (machine_id, employee_id, assigned_date) VALUES (?, ?, NOW())");
    $assign_employee->bind_param('ii', $machine_id, $employee_id);
    $assign_employee->execute();
    $assign_employee->close();
    echo "<script>alert('Employee assigned successfully.'); window.location.href='manage_machine.php';</script>";
}

// Delete Machine
if (isset($_GET['delete_machine'])) {
    $machine_id = $_GET['delete_machine'];

    // Check for existing assignments
    $check_assignments = $conn->prepare("SELECT COUNT(*) FROM machine_assignments WHERE machine_id = ?");
    $check_assignments->bind_param('i', $machine_id);
    $check_assignments->execute();
    $check_assignments->bind_result($assignment_count);
    $check_assignments->fetch();
    $check_assignments->close();

    if ($assignment_count > 0) {
        echo "<script>alert('Cannot delete machine with active assignments.');</script>";
    } else {
        $delete_machine = $conn->prepare("DELETE FROM machines WHERE machine_id = ?");
        $delete_machine->bind_param('i', $machine_id);
        $delete_machine->execute();
        $delete_machine->close();
        echo "<script>alert('Machine deleted successfully.'); window.location.href='manage_machine.php';</script>";
    }
}

// Delete Assignment
if (isset($_GET['delete_assignment'])) {
    $assignment_id = $_GET['delete_assignment'];

    $delete_assignment = $conn->prepare("DELETE FROM machine_assignments WHERE assignment_id = ?");
    $delete_assignment->bind_param('i', $assignment_id);
    $delete_assignment->execute();
    $delete_assignment->close();
    echo "<script>alert('Assignment deleted successfully.'); window.location.href='manage_machine.php';</script>";
}

// Fetch Machines
$machines = $conn->query("SELECT * FROM machines");

// Fetch Assignments
$assignments = $conn->query("SELECT ma.assignment_id, m.machine_name, e.name AS employee_name, ma.assigned_date
    FROM machine_assignments ma
    JOIN machines m ON ma.machine_id = m.machine_id
    JOIN employees e ON ma.employee_id = e.employee_id");
?>

<!DOCTYPE html>
<html>
<head>
    <title>Manage Machines</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f6f9;
            margin: 0;
            padding: 0;
        }
        .container {
            max-width: 1200px;
            margin: 30px auto;
            background: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        }
        h1, h2 {
            text-align: center;
            color: #333;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }
        table, th, td {
            border: 1px solid #ddd;
        }
        th, td {
            padding: 10px;
            text-align: center;
        }
        th {
            background-color: #007bff;
            color: white;
        }
        form {
            margin-bottom: 20px;
        }
        form input, form select, form button {
            padding: 10px;
            margin-right: 10px;
            font-size: 14px;
        }
        form button {
            background-color: #007bff;
            color: white;
            border: none;
            cursor: pointer;
            border-radius: 4px;
        }
        form button:hover {
            background-color: #0056b3;
        }
        .delete-btn {
            color: red;
            text-decoration: none;
        }
        .delete-btn:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Manage Machines</h1>
        <a href="admin_dashboard.php" class="btn back" style="background-color: #007bff; color: white; text-decoration: none; padding: 10px 15px; border-radius: 4px; display: inline-block; margin-bottom: 15px;">Back</a>

        <!-- Add Machine -->
        <h2>Add Machine</h2>
        <form method="POST">
            <input type="text" name="machine_name" placeholder="Machine Name" required>
            <input type="text" name="machine_type" placeholder="Machine Type" required>
            <select name="status" required>
                <option value="Active">Active</option>
                <option value="Inactive">Inactive</option>
            </select>
            <button type="submit" name="add_machine">Add Machine</button>
        </form>

        <!-- Machine List -->
        <h2>Machine List</h2>
        <table>
            <tr>
                <th>Machine ID</th>
                <th>Machine Name</th>
                <th>Machine Type</th>
                <th>Status</th>
                <th>Action</th>
            </tr>
            <?php while ($machine = $machines->fetch_assoc()): ?>
                <tr>
                    <td><?php echo $machine['machine_id']; ?></td>
                    <td><?php echo htmlspecialchars($machine['machine_name']); ?></td>
                    <td><?php echo htmlspecialchars($machine['machine_type']); ?></td>
                    <td><?php echo htmlspecialchars($machine['status']); ?></td>
                    <td>
                        <a href="manage_machine.php?delete_machine=<?php echo $machine['machine_id']; ?>" 
                           class="delete-btn" 
                           onclick="return confirm('Are you sure you want to delete this machine?');">
                           Delete
                        </a>
                    </td>
                </tr>
            <?php endwhile; ?>
        </table>

        <!-- Assign Employee -->
        <h2>Assign Employee to Machine</h2>
        <form method="POST">
            <select name="machine_id" required>
                <option value="" disabled selected>Select Machine</option>
                <?php
                $all_machines = $conn->query("SELECT * FROM machines WHERE status = 'Active'");
                while ($machine = $all_machines->fetch_assoc()): ?>
                    <option value="<?php echo $machine['machine_id']; ?>"><?php echo htmlspecialchars($machine['machine_name']); ?></option>
                <?php endwhile; ?>
            </select>
            <select name="employee_id" required>
                <option value="" disabled selected>Select Employee</option>
                <?php
                $employees = $conn->query("SELECT * FROM employees");
                while ($employee = $employees->fetch_assoc()): ?>
                    <option value="<?php echo $employee['employee_id']; ?>"><?php echo htmlspecialchars($employee['name']); ?></option>
                <?php endwhile; ?>
            </select>
            <button type="submit" name="assign_employee">Assign</button>
        </form>

        <!-- Assignments -->
        <h2>Machine Assignments</h2>
        <table>
            <tr>
                <th>Assignment ID</th>
                <th>Machine Name</th>
                <th>Employee Name</th>
                <th>Assigned Date</th>
                <th>Action</th>
            </tr>
            <?php while ($assignment = $assignments->fetch_assoc()): ?>
                <tr>
                    <td><?php echo $assignment['assignment_id']; ?></td>
                    <td><?php echo htmlspecialchars($assignment['machine_name']); ?></td>
                    <td><?php echo htmlspecialchars($assignment['employee_name']); ?></td>
                    <td><?php echo htmlspecialchars($assignment['assigned_date']); ?></td>
                    <td>
                        <a href="manage_machine.php?delete_assignment=<?php echo $assignment['assignment_id']; ?>" 
                           class="delete-btn" 
                           onclick="return confirm('Are you sure you want to delete this assignment?');">
                           Delete
                        </a>
                    </td>
                </tr>
            <?php endwhile; ?>
        </table>
    </div>
</body>
</html>

<?php
$conn->close();
?>
