<?php
session_start();

// Check if the admin is logged in
if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}

// Database connection
$conn = new mysqli('localhost', 'root', '', 'textilemanagementsystem');
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Search and sort logic
$search_query = '';
$sort_column = 'employee_id'; // Default sort column
$sort_order = 'ASC';          // Default sort order

if (isset($_GET['search'])) {
    $search_query = $_GET['search'];
}

if (isset($_GET['sort']) && in_array($_GET['sort'], ['employee_id', 'name', 'email', 'role', 'date_of_joining'])) {
    $sort_column = $_GET['sort'];
}

if (isset($_GET['order']) && in_array($_GET['order'], ['ASC', 'DESC'])) {
    $sort_order = $_GET['order'];
}

// Fetch employees with search and sorting
$sql = "SELECT * FROM employees 
        WHERE name LIKE ? OR email LIKE ? 
        ORDER BY $sort_column $sort_order";

$stmt = $conn->prepare($sql);
$search_param = '%' . $search_query . '%';
$stmt->bind_param('ss', $search_param, $search_param);
$stmt->execute();
$result = $stmt->get_result();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Employee List</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f8f9fa;
            margin: 0;
            padding: 0;
        }
        .container {
            max-width: 1100px;
            margin: 40px auto;
            background-color: #ffffff;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            overflow: hidden;
            padding: 20px;
        }
        h1 {
            text-align: center;
            font-size: 28px;
            color: #343a40;
            margin-bottom: 20px;
        }
        .button-container {
            text-align: center;
            margin: 15px 0 20px;
        }
        .btn {
            padding: 10px 20px;
            border-radius: 5px;
            border: none;
            font-size: 14px;
            text-decoration: none;
            color: #fff;
            margin: 5px;
            transition: all 0.3s ease;
        }
        .btn-add {
            background-color: #007bff;
        }
        .btn-add:hover {
            background-color: #0056b3;
        }
        .btn-view {
            background-color: #28a745;
        }
        .btn-view:hover {
            background-color: #218838;
        }
        .search-bar {
            text-align: center;
            margin-bottom: 20px;
        }
        .search-bar input[type="text"] {
            width: 300px;
            padding: 10px;
            font-size: 16px;
            border: 1px solid #ddd;
            border-radius: 4px;
        }
        .search-bar button {
            padding: 10px 20px;
            font-size: 16px;
            border: none;
            border-radius: 4px;
            background-color: #007bff;
            color: white;
            cursor: pointer;
            margin-left: 5px;
        }
        .search-bar button:hover {
            background-color: #0056b3;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        table th, table td {
            text-align: left;
            padding: 12px;
        }
        table th {
            background-color: #007bff;
            color: white;
            font-size: 14px;
            text-transform: uppercase;
        }
        table th a {
            color: white;
            text-decoration: none;
        }
        table th a:hover {
            text-decoration: underline;
        }
        table tr:nth-child(even) {
            background-color: #f8f9fa;
        }
        table tr:hover {
            background-color: #f1f1f1;
        }
        table td {
            font-size: 14px;
            color: #343a40;
        }
        .empty-message {
            text-align: center;
            font-size: 16px;
            color: #6c757d;
            margin-top: 20px;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Employee List</h1>
        <a href="admin_dashboard.php" class="btn back" style="background-color: #007bff; color: white; text-decoration: none; padding: 10px 15px; border-radius: 4px; display: inline-block; margin-bottom: 15px;">Back</a>

        <!-- Button Container -->
        <div class="button-container">
            <a href="add_attendance.php" class="btn btn-add">Add Attendance</a>
            <a href="employee_attendence_list.php" class="btn btn-add">View Attendance</a>

        </div>

        <!-- Search Bar -->
        <form method="GET" class="search-bar">
            <input type="text" name="search" placeholder="Search by name or email" value="<?php echo htmlspecialchars($search_query); ?>">
            <button type="submit">Search</button>
        </form>

        <!-- Employee Table -->
        <?php if ($result->num_rows > 0): ?>
            <table>
                <thead>
                    <tr>
                        <th><a href="?sort=employee_id&order=<?php echo $sort_order === 'ASC' ? 'DESC' : 'ASC'; ?>">Employee ID</a></th>
                        <th><a href="?sort=name&order=<?php echo $sort_order === 'ASC' ? 'DESC' : 'ASC'; ?>">Name</a></th>
                        <th><a href="?sort=email&order=<?php echo $sort_order === 'ASC' ? 'DESC' : 'ASC'; ?>">Email</a></th>
                        <th><a href="?sort=role&order=<?php echo $sort_order === 'ASC' ? 'DESC' : 'ASC'; ?>">Role</a></th>
                        <th><a href="?sort=date_of_joining&order=<?php echo $sort_order === 'ASC' ? 'DESC' : 'ASC'; ?>">Date of Joining</a></th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($row = $result->fetch_assoc()): ?>
                        <tr>
                            <td><?php echo $row['employee_id']; ?></td>
                            <td><?php echo htmlspecialchars($row['name']); ?></td>
                            <td><?php echo htmlspecialchars($row['email']); ?></td>
                            <td><?php echo htmlspecialchars($row['role']); ?></td>
                            <td><?php echo htmlspecialchars($row['date_of_joining']); ?></td>
                        </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        <?php else: ?>
            <p class="empty-message">No employees found.</p>
        <?php endif; ?>
    </div>
</body>
</html>

<?php
$stmt->close();
$conn->close();
?>
