<?php
session_start();

// Check if the admin is logged in
if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Textile Management System</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f6f9;
        }
        .header {
            background-color: #343a40;
            color: white;
            padding: 15px 20px;
            text-align: center;
        }
        .sidebar {
            width: 200px;
            height: 100vh;
            background-color: #343a40;
            position: fixed;
            top: 0;
            left: 0;
            color: white;
            padding-top: 20px;
        }
        .sidebar a {
            color: white;
            text-decoration: none;
            display: block;
            padding: 10px 15px;
            border-bottom: 1px solid #454d55;
        }
        .sidebar a:hover {
            background-color: #495057;
        }
        .main-content {
            margin-left: 220px;
            padding: 20px;
        }
        .card {
            background: white;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            margin-bottom: 20px;
            padding: 20px;
            text-align: center;
        }
        .card a {
            text-decoration: none;
            color: #007bff;
            font-size: 16px;
            font-weight: bold;
        }
        .card a:hover {
            color: #0056b3;
        }
        .logout-btn {
            background-color: #dc3545;
            color: white;
            border: none;
            padding: 10px 15px;
            cursor: pointer;
            border-radius: 4px;
            font-size: 14px;
        }
        .logout-btn:hover {
            background-color: #c82333;
        }
    </style>
</head>
<body>
    <div class="header">
        <h1>Textile Management System</h1>
    </div>
    <div class="sidebar">
        <a href="admin_dashboard.php">Dashboard</a>
        <a href="manage_orders.php">Manage Orders</a>
        <a href="add_order.php">Add Order</a>
        <a href="manage_customers.php">Manage Customers</a>
        <a href="manage_fabrics.php">Manage Fabrics</a>
        <a href="manage_Carriers.php">Manage Carriers</a>
        <a href="manage_employees.php">Manage Employees</a>
        <a href="manage_machine.php">Manage Machine</a>
        <!--<a href="userlist.php">Order Recieving</a>  New Order Recieving Link -->
        <form method="POST" action="logout.php" style="padding: 15px;">
            <button type="submit" class="logout-btn">Logout</button>
        </form>
    </div>
    <div class="main-content">
        <h2>Welcome, <?php echo htmlspecialchars($_SESSION['username']); ?>!</h2>
        <div class="card">
            <a href="customer_list.php">Customer List</a>
        </div>
        <div class="card">
            <a href="carrier_list.php">Carriers</a>
        </div>
        <div class="card">
            <a href="employee_list.php">Employees</a>
        </div>
        <div class="card">
            <a href="userlist.php">Order Recieving</a>
        </div>
    </div>
</body>
</html>
