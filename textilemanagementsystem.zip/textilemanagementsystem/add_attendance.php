<?php
session_start();

// Check if the admin is logged in
if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}

// Database connection
$conn = new mysqli('localhost', 'root', '', 'textilemanagementsystem');
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Handle attendance submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $date = $_POST['date'];
    $attendance_data = $_POST['attendance'];

    // Loop through the attendance data
    foreach ($attendance_data as $employee_id => $status) {
        $stmt = $conn->prepare("INSERT INTO attendance (employee_id, date, status) VALUES (?, ?, ?)
                                ON DUPLICATE KEY UPDATE status = VALUES(status)");
        $stmt->bind_param("iss", $employee_id, $date, $status);
        $stmt->execute();
    }
    echo "<div class='success-message'>Attendance updated successfully!</div>";
}

// Fetch employees
$result = $conn->query("SELECT employee_id, name FROM employees");
?>

<!DOCTYPE html>
<html>
<head>
    <title>Add Attendance</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f6f9;
        }
        .container {
            max-width: 800px;
            margin: 50px auto;
            background: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        }
        h1 {
            text-align: center;
            color: #333;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        table, th, td {
            border: 1px solid #ddd;
        }
        th, td {
            padding: 10px;
            text-align: center;
        }
        th {
            background-color: #007bff;
            color: white;
        }
        .form-actions {
            text-align: center;
            margin-top: 20px;
        }
        .btn {
            padding: 10px 15px;
            background-color: #007bff;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }
        .btn:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Mark Employee Attendance</h1>
        <a href="employee_list.php" class="btn back" style="background-color: #007bff; color: white; text-decoration: none; padding: 10px 15px; border-radius: 4px; display: inline-block; margin-bottom: 15px;">Back</a>
        <form method="POST">
            <label for="date">Date:</label>
            <input type="date" id="date" name="date" required>
            <table>
                <tr>
                    <th>Employee ID</th>
                    <th>Employee Name</th>
                    <th>Status</th>
                </tr>
                <?php while ($row = $result->fetch_assoc()): ?>
                <tr>
                    <td><?php echo $row['employee_id']; ?></td>
                    <td><?php echo htmlspecialchars($row['name']); ?></td>
                    <td>
                        <select name="attendance[<?php echo $row['employee_id']; ?>]" required>
                            <option value="Present">Present</option>
                            <option value="Absent">Absent</option>
                            <option value="Leave">Leave</option>
                        </select>
                    </td>
                </tr>
                <?php endwhile; ?>
            </table>
            <div class="form-actions">
                <button type="submit" class="btn">Submit Attendance</button>
            </div>
        </form>
    </div>
</body>
</html>

<?php
$conn->close();
?>
